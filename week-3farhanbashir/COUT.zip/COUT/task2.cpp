#include <iostream>
using namespace std;

int main() {

    cout << "\t    *" << endl;
    cout << "\t  *    *" << endl;
    cout << "\t *      *" << endl;
    cout <<"\t**********" << endl;




}