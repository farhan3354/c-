#include <iostream>
using namespace std;

int main() {

    cout << "\t          *************************************" << endl;
    cout << "\t                  \n \t \t\t\tResult Sheet                                                " << endl;
    cout << "\t                                                                  " << endl;
    cout << "\t          *************************************" << endl;

    cout << "\t Students roll no        Math      Physics      Chem      Total  " << endl;
    cout << "\t ---------------------------------------------------------------------" << endl;
    cout << "\t       1212               89          76           87      252  " << endl;
    cout << "\t ---------------------------------------------------------------------" << endl;

}