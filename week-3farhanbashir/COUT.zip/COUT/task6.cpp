#include <iostream>
using namespace std;

int main() {

    cout << "\t *****************************************************************" << endl;
    cout << "\t *                                                               *" << endl;
    cout << "\t *    \t   Progamming Assignment 1                               *" << endl;
    cout << "\t *    \t   Computer Programming  1                               *" << endl;
    cout << "\t *    \t         Author:???                                      *" << endl;
    cout << "\t *    \t   Due Date :Thursday ,Jan.24                            *" << endl;
    cout << "\t *                                                               *" << endl;
    cout << "\t *                                                               *" << endl;
    cout << "\t *****************************************************************" << endl;

}