#include <iostream>
using namespace std;

int main() {

    cout << "\tName:\t My Name is Farhan" << endl;
    cout << "\tRegistration No:\t L1F24BSCS1068" << endl;
    cout << "\tEmail:\t farhanbashir3354@gmail.com" << endl;
    cout << "\tGender:\t Male" << endl;
    cout << "\tAge:\t 19" << endl;
    cout << "\tHometown:\t Ali Town" << endl;

}