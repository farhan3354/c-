#include <iostream>
using namespace std;

int main() {

    cout << "\t Hello, World!" << "\n" << "\t This is a C++ program" << endl;


}