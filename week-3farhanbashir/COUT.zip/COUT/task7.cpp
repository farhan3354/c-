#include <iostream>
using namespace std;

int main() {

    cout  << "\t   CCCCCCCCCCCC"  << endl;
    cout  << "\t  CC"            <<"\t\t         ++"       << "\t\t         ++" << endl;
    cout  << "\t CC"             <<"\t\t         ++"       << "\t\t         ++" << endl;
    cout  << "\tCC"              <<"\t\t    ++++++ ++ +++" << "\t    ++++++ ++ +++" << endl;
    cout  << "\tCC"              <<"\t\t     +++++ ++ ++"  << "\t     +++++ ++ ++" << endl;
    cout  << "\t CC"             <<"\t\t         ++"       << "\t\t         ++" << endl;
    cout  << "\t  CC"            <<"\t\t         ++"       << "\t\t         ++" << endl;
    cout  << "\t   CCCCCCCCCCCC" << endl;

}