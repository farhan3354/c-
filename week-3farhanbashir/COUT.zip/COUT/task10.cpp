#include <iostream>
using namespace std;

int main() {
    cout << "\t\t      ." << "\t\t\t      ." << endl;
    cout << "\t\t      .." << "\t\t     .." << endl;
    cout << "\t\t      ...." << "\t\t    ..." << endl;
    cout << "\t\t      ....." << "\t\t   ...." << endl;
    cout << "\t\t      ......" << "\t\t  ....." << endl;
    cout << "\t\t      ......." << "\t\t ......" << endl;

    cout << "\n\n\t\t      ......." << "\t\t ......." << endl;
    cout << "\t\t      ......" << "\t\t  ......" << endl;
    cout << "\t\t      ....." << "\t\t   ....." << endl;
    cout << "\t\t      ...." << "\t\t    ...." << endl;
    cout << "\t\t      .." << "\t\t      .." << endl;
    cout << "\t\t      ." << "\t\t\t       ." << endl;

}