#include <iostream>
using namespace std;

int main() {

    cout << "\t U \t\tU" << "\t   CCCCCCCCCCCC" <<"\t    PPPPPPPP" <<"\t    CCCCCCCCCC" <<"\t   SSSSSSSSSS" << endl;
    cout << "\t U \t\tU" << "\t  CC"            <<"\t\t  P" << "\t    P" << "\t   CC" <<"\t\t  SS" << endl;
    cout << "\t U \t\tU" << "\t CC"             <<"\t\t  P" << "\t    P" << "\t  CC" <<"\t\tSS" << endl;
    cout << "\t U \t\tU" << "\tCC"              <<"\t\t  P" << "  PPPPP" << "\t CC" <<"\t\t  SS   SS   SS" << endl;
    cout << "\t U \t\tU" << "\tCC"              <<"\t\t  P" << "\t \t CC"           <<"\t\t           SS" << endl;
    cout << "\t U \t\tU" << "\t CC"             <<"\t\t  P" << "\t \t  CC"          <<"\t\t          SS" << endl;
    cout << "\t U \t\tU" << "\t  CC"            <<"\t\t  P" << "\t  \t   CCCCCCCCCCC"  <<"\tSSSSSSSSSS" << endl;
    cout << "\t  UUUUUUUUUUUUUU" << "\t   CCCCCCCCCCCC" << endl;

}