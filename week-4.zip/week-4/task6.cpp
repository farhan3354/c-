#include<iostream>
using namespace std;
int main()
{
	int a, b;
	char ch;
	cout << "Enter number one : ";
	cin >> a;
	cout << "Enter number two : ";
	cin >> b;
	cout << "Enter operator : ";
	cin >> ch;
	if (ch == '+')
	{
		int sum;
		sum = a + b;
		cout << "sum of number is : " << sum << endl;
	}
	else if (ch == '+')
	{
		int mod;
		mod = a % b;
		cout << "modolus of number is : " << mod << endl;
	}
	else if (ch == '-')
	{
		int sub;
		sub = a - b;
		cout << "subraction of number is : " << sub << endl;
	}
	else if (ch == '/')
	{
		int div;
		div = a / b;
		cout << "division of number is : " << div << endl;
	}
	else if (ch == '*')
	{
		int mul;
		mul = a * b;
		cout << "multipication of number is : " << mul << endl;
	}
	return 0;
}