#include <iostream>
using namespace std;

int main() {

  /*  float a;
     int b;
    cout << "Enter number 1 : ";
    cin >> a;

    b = a;
    if (b != a) {
        b = b + 1;
        cout << "The number is now ceiling Integer " << b;
    }
    else
    {
        cout << "The number is without ceiling Integer " << a;
    }*/


    int a, b, c;

    cout << "Enter number 1 : ";
    cin >> a;
    cout << "Enter number 2 : ";
    cin >> b;
    cout << "Enter number 3 : ";
    cin >> c;

    if ((a <= b && a >= c)||(a>=b && a <= c )){

        cout<<"The second maximum value is : "<<a;
    }
    else if ((b <= a && b >= c) || (b >= a && b <= c)) {
        cout << "The second maximum value is : " << b;

    }
    else  {
        cout << "The second maximum value is : " << c;

    }


  /*  float marks;
    int ceiled_marks;
    float GPA;
    cout << " Enter your Marks Obtained in ITC-LAB :";
    cin >> marks;
    ceiled_marks = marks;
    if (ceiled_marks != marks) {
        ceiled_marks = ceiled_marks + 1;
    }
    else
    {
        ceiled_marks = marks;
    }
    marks = ceiled_marks;

    if (marks >= 86) {
        cout << "Your Grade is A";
        GPA = 4.0;
    }
    else if (marks <= 85 && marks >= 82) {
        cout << "Your Grade is A-";
        GPA = 3.67;
    }
    else if (marks <= 81 && marks >= 78) {
        cout << "Your Grade is B+";
        GPA = 3.40;
    }
    else if (marks <= 77 && marks >= 73) {
        cout << "Your Grade is B";
        GPA = 3.0;
    }
    else if (marks <= 72 && marks >= 68) {
        cout << "Your Grade is B-";
        GPA = 2.58;
    }
    else if (marks <= 67 && marks >= 60) {
        cout << "Your Grade is C-";
        GPA = 2.11;
    }
    else if (marks <= 59 && marks >= 50) {
        cout << "Your Grade is F";
        GPA = 1.98;
    }*/


}