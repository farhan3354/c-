#include<iostream>
using namespace std;
int main()
{
	int math, English, urdu;

	cout << "Enter marks of math : ";
	cin >> math;
	cout << "Enter marks of English : ";
	cin >> English;
	cout << "Enter marks of Urdu : ";
	cin >> urdu;
	 
	int ave;
	ave = (math + English + urdu) / 3;
	cout << "Average of marks is : "<< ave << endl;

	if (ave > 80)
	{
		cout << "\n\nYou're above standard" << endl << "Admmission Granted!" << endl;
	}



	return 0;
}