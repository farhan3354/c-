#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	
	cout << "Enter number a : ";
	cin >> a;
	cout << "Enter number b : ";
	cin >> b;
	cout << "Enter number c : ";
	cin >> c;

	if ((a > b) && (a > c))
		cout << "A is largest number " << endl;

	if ((b > a) && (b > c))
		cout << "B is largest number " << endl;


	if ((c > a) && (c > b))
		cout << "C is largest number " << endl;




	return 0;
}