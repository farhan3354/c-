#include <iostream>
using namespace std;

int main() {
    float weight, height, bmi;

    cout << "Enter your weight in kilograms: ";
    cin >> weight;

    cout << "Enter your height in meters: ";
    cin >> height;

    bmi = weight / (height * height);

    cout << "Your BMI is: " << bmi << endl;

    if (bmi < 1.5) {
        cout << "You are underweight." << endl;
    }
    else if (bmi >= 1.5 && bmi < 1.9) {
        cout << "You have a normal weight." << endl;
    }
    else if (bmi >= 2.1 && bmi < 2.9) {
        cout << "You are overweight." << endl;
    }
    else if (bmi >= 3.0) {
        cout << "You have obesity." << endl;
    }

    return 0;
}



//#include <iostream>
//using namespace std;
//int main()
//{
//	int num1, num2, num3;
//	cin >> num1;
//	cin >> num2;
//	cin >> num3;
//	int largest;
//	int slarge;
//	if ((num1 > num2) && (num1 > num3))
//	{
//		largest = num1;
//		if (num2 > num3)
//		{
//			slarge = num2;
//		}
//		else
//		{
//			slarge = num3;
//		}
//	}
//	else if ((num2 > num3) && (num2 > num1))
//	{
//		largest = num2;
//		if (num1 > num3)
//		{
//			slarge = num1;
//		}
//		else
//		{
//			slarge = num3;
//		}
//	}
//	else
//	{
//		largest = num3;
//		if (num1 > num2)
//		{
//			slarge = num1;
//		}
//		else
//		{
//			slarge = num2;
//		}
//	}
//	cout << slarge;
//	return 0;
//}