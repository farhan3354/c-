#include <iostream>
using namespace std;

int main() {

    int a, b, c, d, e, f;

    cout << "6 sections average : " << endl;

    cout << "A\t";
    cin >> a;
    cout << "B\t";
    cin >> b;
    cout << "C\t";
    cin >> c;
    cout << "D\t";
    cin >> d;
    cout << "E\t";
    cin >> e;
    cout << "F\t";
    cin >> f;

    if (a > b && a > c && a > d && a > e && a > f) {
        cout << "A got the highest average " << a;
    }
    else if (b > a && b > c && b > d && b > e && b > f) {
        cout << "B got the highest average " << b;
    }
    else if (c > a && c > b && c > d && c > e && c > f) {
        cout << "C got the highest average " << c;
    }
    else if (d > a && d > c && d > b && d > e && d > f) {
        cout << "D got the highest average " << d;
    }
    else if (e > a && e > c && e > d && e > b && e > f) {
        cout << "E got the highest average " << e;
    }
    else if (f > a && f > c && f > d && f > e && f > b) {
        cout << "F got the highest average " << f;
    }



}