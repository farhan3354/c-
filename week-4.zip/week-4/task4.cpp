#include<iostream>
using namespace std;
int main()
{
	int a;
	
	cout << "Enter number : ";
	cin >> a;
	

	if (a < 0)
		cout << "Number is negative " << endl;

	else if (a > 0)
		cout << "Number is positive " << endl;

	else if (a == 0)
		cout << "Number is zero" << endl;



	return 0;
}