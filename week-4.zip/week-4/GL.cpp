#include<iostream>
using namespace std;
int main()
{
	float speed;

	cout << "Enter Speed in miles per hour: ";
	cin >> speed;

	float S_kmh;
	float mile1 = 1.60934;
	S_kmh = speed * mile1;
	cout << "Speed in km/h is : " << S_kmh<<" km/h" << endl;

	float S_mps;
	float kmh1 = 0.277778;
	S_mps = 0.27778 * kmh1;
	cout << "Speed in mps is : " << S_mps<<" mps" << endl;




	return 0;
}